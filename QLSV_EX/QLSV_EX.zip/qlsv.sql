-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2022 at 03:12 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlsv`
--

-- --------------------------------------------------------

--
-- Table structure for table `challenge`
--

CREATE TABLE `challenge` (
  `id` int(11) NOT NULL,
  `teacherId` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filePath` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `challenge`
--

INSERT INTO `challenge` (`id`, `teacherId`, `title`, `description`, `filePath`, `created_at`, `updated_at`) VALUES
(10, 1, 'đoán tên bài thơ', 'bài thơ liên quan đến mưa', 'da-khuc-mua.txt', '2022-03-25 11:13:07', '2022-03-25 11:13:07');

-- --------------------------------------------------------

--
-- Table structure for table `exercise`
--

CREATE TABLE `exercise` (
  `id` int(11) NOT NULL,
  `teacherId` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filePath` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `exercise`
--

INSERT INTO `exercise` (`id`, `teacherId`, `title`, `description`, `filePath`, `updated_at`, `created_at`) VALUES
(21, 1, 'bai 1', '123', 'Lecture_06.pptx', '2022-03-24 05:06:06', '2022-03-24 05:06:06'),
(22, 1, 'bài 2', '345', 'Part 3_Time Management.docx', '2022-03-24 05:06:06', '2022-03-24 05:06:06'),
(23, 2, 'bài 3', '5667', 'hw5.pdf', '2022-03-23 21:59:01', '2022-03-23 21:59:01'),
(26, 1, 'bài 5', '123455', 'Lecture_05-4.pptx', '2022-03-24 10:33:02', '2022-03-24 10:33:02'),
(27, 1, 'bài 6', '4556', 'part2.docx', '2022-03-24 10:35:50', '2022-03-24 10:35:50'),
(28, 1, 'bai 7', 'bai 7', 'part2 - Copy.docx', '2022-03-25 11:12:18', '2022-03-25 11:12:18');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `sendId` int(11) NOT NULL,
  `receiveId` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `sendId`, `receiveId`, `content`, `created_at`, `updated_at`) VALUES
(45, 11, 1, 'alo', '2022-03-25 11:24:53', '2022-03-25 11:21:04'),
(46, 11, 1, 'ok b', '2022-03-25 11:25:25', '2022-03-25 11:25:25'),
(47, 11, 1, 'chao co a', '2022-03-25 11:25:43', '2022-03-25 11:25:43'),
(48, 11, 2, 'chao co a', '2022-03-25 11:26:11', '2022-03-25 11:26:11'),
(49, 11, 2, 'vang', '2022-03-25 11:26:16', '2022-03-25 11:26:16'),
(50, 11, 7, 'chao ban', '2022-03-25 11:26:28', '2022-03-25 11:26:28'),
(51, 11, 7, 'ok b', '2022-03-25 11:26:33', '2022-03-25 11:26:33'),
(53, 1, 7, 'ly do nay nghi hoc la gi vay????', '2022-03-25 11:35:56', '2022-03-25 11:35:56'),
(54, 1, 16, 'chao', '2022-03-25 11:36:16', '2022-03-25 11:36:16'),
(55, 1, 16, 'hello', '2022-03-25 11:36:23', '2022-03-25 11:36:23');

-- --------------------------------------------------------

--
-- Table structure for table `sbmexercise`
--

CREATE TABLE `sbmexercise` (
  `id` int(11) NOT NULL,
  `exerciseId` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `filePath` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sbmexercise`
--

INSERT INTO `sbmexercise` (`id`, `exerciseId`, `studentId`, `filePath`, `created_at`, `updated_at`) VALUES
(5, 21, 11, 'Lecture_06.pptx', '2022-03-08 13:42:04', NULL),
(6, 21, 7, 'Lecture_06.pptx', '2022-03-24 04:28:38', NULL),
(7, 22, 11, 'Lecture_06.pptx', '2022-03-24 10:02:55', '2022-03-24 10:02:55'),
(8, 28, 11, 'Lecture_06 - Copy.pptx', '2022-03-25 11:14:19', '2022-03-25 11:14:19');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phoneNumber` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('student','teacher','admin') COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `fullname`, `email`, `phoneNumber`, `type`, `avatar`, `updated_at`, `created_at`) VALUES
(1, 'teacher1', '123456a@A', 'Giáo viên 1', 'teacher@admin.com', '012345678', 'teacher', 'ANHDEP4 - Copy.png', '2022-03-23 10:41:49', NULL),
(2, 'teacher2', '123456a@A', 'Giáo viên 2', 'trang@gmail.com', '0258741369', 'teacher', 'ANHDEP.png', NULL, NULL),
(7, 'student2', '123456a@A', 'Học sinh 2', 'hocsinh2@gmail.com', '0123456787', 'student', 'ANHDEP2-Copy(1).png', '2022-03-23 10:42:15', NULL),
(11, 'student1', '123456a@A', 'Học sinh 1', 'hocsinh11@gmail.com', '1234567763', 'student', 'ANHDEP.png', '2022-03-25 11:15:30', NULL),
(16, 'student5', '1234567', 'student5', 'student5@gmail.com', '037897775', 'student', 'ANHDEP4 - Copy(1).png', '2022-03-25 11:34:06', '2022-03-25 11:27:57'),
(17, 'student6', '12345678', 'student6', 'student6@gmail.com', '22338444', 'student', 'ANHDEP3.png', '2022-03-25 11:29:42', '2022-03-25 11:29:42'),
(18, 'student8', '12345678', 'student8', 'student8@gmail.com', '038977654', 'student', 'ANHDEP1.png', '2022-03-25 11:35:04', '2022-03-25 11:35:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `challenge`
--
ALTER TABLE `challenge`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacherId` (`teacherId`);

--
-- Indexes for table `exercise`
--
ALTER TABLE `exercise`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacherId` (`teacherId`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sendId` (`sendId`),
  ADD KEY `receiveId` (`receiveId`);

--
-- Indexes for table `sbmexercise`
--
ALTER TABLE `sbmexercise`
  ADD PRIMARY KEY (`id`),
  ADD KEY `exerciseId` (`exerciseId`),
  ADD KEY `studentId` (`studentId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `challenge`
--
ALTER TABLE `challenge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `exercise`
--
ALTER TABLE `exercise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `sbmexercise`
--
ALTER TABLE `sbmexercise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `challenge`
--
ALTER TABLE `challenge`
  ADD CONSTRAINT `challenge_ibfk_1` FOREIGN KEY (`teacherId`) REFERENCES `user` (`id`);

--
-- Constraints for table `exercise`
--
ALTER TABLE `exercise`
  ADD CONSTRAINT `exercise_ibfk_1` FOREIGN KEY (`teacherId`) REFERENCES `user` (`id`);

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`sendId`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `message_ibfk_2` FOREIGN KEY (`receiveId`) REFERENCES `user` (`id`);

--
-- Constraints for table `sbmexercise`
--
ALTER TABLE `sbmexercise`
  ADD CONSTRAINT `sbmExercise_ibfk_1` FOREIGN KEY (`exerciseId`) REFERENCES `exercise` (`id`),
  ADD CONSTRAINT `sbmExercise_ibfk_2` FOREIGN KEY (`studentId`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
