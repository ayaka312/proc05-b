<?php 
use App\User;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Thêm sinh viên</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/mycss.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
                <li class='active'><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li><a href="<?php echo e(route('listExercise')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm bài tập
                        <?php else: ?>
                            Danh sách bài tập
                        <?php endif; ?>

                    </a>
                </li>
                <li><a href="<?php echo e(route('listChallenge')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm challenge
                        <?php else: ?>
                            Challenge
                        <?php endif; ?>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!empty(session('username'))): ?>
                    <?php
                        $user = User::where('username', session('username'))->first();
                    ?>
                    <li><a href="<?php echo e(route('editUser', $user->id)); ?>"><span class="glyphicon glyphicon-user"></span>
                            Thông tin
                            người dùng</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>"><span class="glyphicon glyphicon-log-out"></span> Đăng xuất</a>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-user"></span>
                            Đăng nhập</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="center">
            <br>
            <br>
            <h2>Điền thông tin sinh viên </h2>
            <form action="<?php echo e(route('storeUser')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Tên đăng nhập</label>
                    <input type="text" name="username" class="form-control" value="<?php echo e(request()->old('username')); ?>">
                    <span class="help-block"></span>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Mật khẩu</label>
                    <input type="password" name="password" class="form-control"
                        value="<?php echo e(request()->old('password')); ?>">
                    <span class="help-block"></span>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Nhập lại mật khẩu</label>
                    <input type="password" name="password_confirmation" class="form-control" value="">
                    <span class="help-block"></span>
                </div>
                <div class="form-group">
                    <label>Họ tên</label>
                    <input type="text" name="fullname" class="form-control"
                        value="<?php echo e(request()->old('fullname')); ?>">
                    <span class="help-block"></span>
                    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(request()->old('email')); ?>">
                    <span class="help-block"></span>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Số điện thoại</label>
                    <input type="tel" name="phoneNumber" class="form-control"
                        value="<?php echo e(request()->old('phoneNumber')); ?>">
                    <span class="help-block"></span>
                    <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Là: </label>
                    <select name="type">
                        <option value="student">Student</option>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>Ảnh</label>
                    <input name="file" type="file" class="form-control" value="">
                    <span class="help-block"></span>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Đồng ý">
                    <input type="reset" class="btn btn-default" value="Làm mới">
                </div>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\xampp-1\htdocs\QLSV_EX\resources\views/addUser.blade.php ENDPATH**/ ?>