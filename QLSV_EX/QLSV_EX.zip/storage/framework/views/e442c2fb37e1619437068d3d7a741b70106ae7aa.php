<?php
use App\User;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Chỉnh sửa thông tin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/mycss.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
                <li class='active'><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li><a href="<?php echo e(route('listExercise')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm bài tập
                        <?php else: ?>
                            Danh sách bài tập
                        <?php endif; ?>

                    </a>
                </li>
                <li><a href="<?php echo e(route('listChallenge')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm challenge
                        <?php else: ?>
                            Challenge
                        <?php endif; ?>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!empty(session('username'))): ?>
                    <?php
                        $user = User::where('username', session('username'))->first();
                    ?>
                    <li><a href="<?php echo e(route('editUser', $user->id)); ?>"><span class="glyphicon glyphicon-user"></span>
                            Thông tin
                            người dùng</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>"><span class="glyphicon glyphicon-log-out"></span> Đăng xuất</a>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-user"></span>
                            Đăng nhập</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="page-header">
        <h1>Chỉnh sửa thông tin</h1>
    </div>

    <div class="container">
        <form action="<?php echo e(route('updateUser', $userInfo->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(session('type') == 'teacher'): ?>
                <div class='form-group'>
                    <label>Tên đăng nhập: </label>
                    <input class='form-control' type='username' name='username' value='<?php echo e($userInfo->username); ?>'>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class='form-group'>
                    <label>Họ tên: </label>
                    <input class='form-control' type='text' name='fullname' value='<?php echo e($userInfo->fullname); ?>'>
                    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class='text-danger'><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <label>Mật khẩu: </label>
                <input class="form-control" type="password" name="password" value="<?php echo e($userInfo->password); ?>">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class='text-danger'><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Email: </label>
                <input class="form-control" type="email" name="email" value="<?php echo e($userInfo->email); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class='text-danger'><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label>Số điện thoại: </label>
                <input class="form-control" type="tel" name="phoneNumber" value="<?php echo e($userInfo->phoneNumber); ?>"
                    pattern="[0-9]{7,10}">
                <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class='text-danger'><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label>Ảnh sản phẩm</label>
                <input name="file" type="file" class="form-control" value="">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class='text-danger'><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button class="btn btn-success" type='submit'>Xác nhận</button>
        </form>

    </div>

</body>

</html>
<?php /**PATH E:\xampp\htdocs\QLSV_EX\resources\views/editUser.blade.php ENDPATH**/ ?>