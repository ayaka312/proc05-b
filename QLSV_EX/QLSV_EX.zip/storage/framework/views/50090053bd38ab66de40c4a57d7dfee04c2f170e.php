<?php
use App\User;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Sửa tin nhắn</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/mycss.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
                <li class='active'><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li><a href="<?php echo e(route('listExercise')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm bài tập
                        <?php else: ?>
                            Danh sách bài tập
                        <?php endif; ?>

                    </a>
                </li>
                <li><a href="<?php echo e(route('listChallenge')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm challenge
                        <?php else: ?>
                            Challenge
                        <?php endif; ?>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!empty(session('username'))): ?>
                    <?php
                        $user = User::where('username', session('username'))->first();
                    ?>
                    <li><a href="<?php echo e(route('editUser', $user->id)); ?>"><span class="glyphicon glyphicon-user"></span>
                            Thông tin
                            người dùng</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>"><span class="glyphicon glyphicon-log-out"></span> Đăng xuất</a>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-user"></span>
                            Đăng nhập</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <div class="page-header">
        <h1>Sửa tin nhắn</h1>
    </div>
    <div class="container">
        <form action='<?php echo e(route('updateMessage', $message->id)); ?>' method='post'>
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <input type="text" class="newmess" class="form-control " placeholder="Gửi tin nhắn"
                    name='messageContent' required value='<?php echo e($message->content); ?>'>
                <span class="input-group-btn">
                    <button class="sendmess" type="submit" class="btn btn-default">
                        Gửi
                    </button>
                </span>
            </div>
        </form>
    </div>

    </body>

</html>
<?php /**PATH E:\xampp\htdocs\QLSV_EX\resources\views/editMessage.blade.php ENDPATH**/ ?>