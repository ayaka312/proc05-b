<?php
use App\User;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Danh sách nộp</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/mycss.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>

<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
                <li class='active'><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li><a href="<?php echo e(route('listExercise')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm bài tập
                        <?php else: ?>
                            Danh sách bài tập
                        <?php endif; ?>

                    </a>
                </li>
                <li><a href="<?php echo e(route('listChallenge')); ?>">
                        <?php if(session('type') == 'teacher'): ?>
                            Thêm challenge
                        <?php else: ?>
                            Challenge
                        <?php endif; ?>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!empty(session('username'))): ?>
                    <?php
                        $user = User::where('username', session('username'))->first();
                    ?>
                    <li><a href="<?php echo e(route('editUser', $user->id)); ?>"><span class="glyphicon glyphicon-user"></span>
                            Thông tin
                            người dùng</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>"><span class="glyphicon glyphicon-log-out"></span> Đăng xuất</a>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-user"></span>
                            Đăng nhập</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <div class="page-header">
        <h1>Danh sách nộp</h1>
    </div>
    <div class='container'>
        <div class="panel panel-success">
            <div class="panel-heading">Bài tập: <?php echo e($exercise->title); ?></div>
            <div class='panel-body'>Gợi ý: <?php echo e($exercise->description); ?></div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">Danh sách đã nộp</div>
            <?php if($listSubmited->count() > 0): ?>
                <div class="panel-body">
                    <?php $__currentLoopData = $listSubmited; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='panel panel-info'>
                            <div class='panel-heading'>Họ tên: <?php echo e($submit->fullname); ?></div>
                            <div class='panel-body'>Thời gian nộp: <?php echo e($submit->created_at); ?></div>
                            <div class='panel-body'><a role='button' class='btn btn-warning'
                                    href='<?php echo e(url('uploads/sbmExercises/std' . $submit->studentId . '/' . $submit->filePath)); ?>'>File:
                                    <?php echo e($submit->filePath); ?></a></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\QLSV_EX\resources\views/seeSbmExercise.blade.php ENDPATH**/ ?>